package basedatos;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

import Common.DatosUsuario;
import Common.Trino;


public class AlmacenBasededatos {

	private List<DatosUsuario> listaUsuarios;
	
	private HashMap<String,List<DatosUsuario>> seguidores;
	
	private HashMap<String,List<Trino>> trinosPendientes;
	
	public AlmacenBasededatos(){
		listaUsuarios = new ArrayList<DatosUsuario>();
		seguidores = new HashMap<>();
		trinosPendientes = new HashMap<>();
		
	}
	
	public DatosUsuario obtenerUsuario(String nick){
		if(listaUsuarios != null && nick != null){
			for(DatosUsuario usuario : listaUsuarios){
				if(nick.equals(usuario.obtenerNick())){
					return usuario;
					
				}
			}
			
		}
		return null;
	}
	
	public boolean seguirUsuario(String nick, String objetivo){
		DatosUsuario usuario = obtenerUsuario(nick);
		if(nick != null){
			List<DatosUsuario> seguidoresUsuario = seguidores.get(objetivo);
			if(seguidoresUsuario == null){
				seguidoresUsuario = new ArrayList<DatosUsuario>();
			}
			
			if(!seguidoresUsuario.contains(usuario)){
				seguidoresUsuario.add(usuario);
				seguidores.put(objetivo, seguidoresUsuario);
				return true;
			}
		}
		return false;
	}
	
	public boolean dejarSeguirUsuario(String nick, String objetivo){
		DatosUsuario usuario = obtenerUsuario(nick);
		if(nick != null){
			List<DatosUsuario> seguidoresUsuario = seguidores.get(objetivo);
			if(seguidoresUsuario.contains(usuario)){
				seguidoresUsuario.remove(usuario);
				seguidores.put(objetivo, seguidoresUsuario);
				return true;
			}
		}
		return false;
	}
	
	public boolean aniadirTrino(String nick, Trino trino){
		if(nick != null){
			List<Trino> seguidoresUsuario = trinosPendientes.get(nick);
			if(seguidoresUsuario == null){
				seguidoresUsuario = new ArrayList<Trino>();
			}
			
			if(!seguidoresUsuario.contains(trino)){
				seguidoresUsuario.add(trino);
				trinosPendientes.put(nick, seguidoresUsuario);
				return true;
			}
		}
		return false;
		
	}
	
	public boolean borrarTrino(String nick, Trino trino){
		if(nick != null){
			List<Trino> seguidoresUsuario = trinosPendientes.get(nick);
			if(seguidoresUsuario == null){
				seguidoresUsuario = new ArrayList<Trino>();
			}
			
			if(seguidoresUsuario.contains(trino)){
				seguidoresUsuario.remove(trino);
				trinosPendientes.put(nick, seguidoresUsuario);
				return true;
			}
		}
		return false;
		
	}
	
	public List<DatosUsuario> obtenerUsuarios(){
		return listaUsuarios;
	}
	
	public List<String> obtenerNicks(){
		
		List<String> listaNicks = new ArrayList<String>();
		
		for (DatosUsuario usuario : listaUsuarios) {
			
			listaNicks.add(usuario.obtenerNick());
			
		}
		return listaNicks;
	}
	
	public List<DatosUsuario> obtenerSeguidores(String nick){
		return seguidores.get(nick);
	}
	
	public List<Trino> obtenerTrinosPendientes(String nick){
		return trinosPendientes.get(nick);
	}
	
	public List<Trino> obtenerTrinosNoPublicados(String nick){
		List<Trino> listaNoPublicados = new ArrayList<Trino>();
		if(trinosPendientes != null){
			for (Entry<String, List<Trino>> entry : trinosPendientes.entrySet()){
				List<Trino> trinosPendientsUsuario = entry.getValue();
				if(trinosPendientsUsuario != null){
					for(Trino trino : trinosPendientsUsuario){
						if(nick.equals(trino.ObtenerNickPropietario())){
							if(!listaNoPublicados.contains(trino)){
								listaNoPublicados.add(trino);
							}
							
						}
						
					}
					
				}
				
			}			
		}
		return listaNoPublicados;
		
	}
	
	public boolean borrarTrinosNoPublicado(String trinoID){
		boolean out = false;
		if(trinosPendientes != null){
			for (Entry<String, List<Trino>> entry : trinosPendientes.entrySet()){
				List<Trino> trinosPendientsUsuario = entry.getValue();
				if(trinosPendientsUsuario != null){
					for(Trino trino : trinosPendientsUsuario){
						if(trinoID.equals(trino.toString())){
							trinosPendientsUsuario.remove(trino);
							out = true;
						}
						
					}
					
				}
				
			}			
		}
		return out;
	}

	public boolean addUsuario(String nombre, String nick, String password) {
		
		DatosUsuario nuevoUsuario = new DatosUsuario(nombre,nick,password);
		return listaUsuarios.add(nuevoUsuario);
		
	}
	
}
