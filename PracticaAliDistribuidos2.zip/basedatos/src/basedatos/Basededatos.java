package basedatos;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;
import java.util.Scanner;
import Common.DatosUsuario;
import servidor.ServicioAutenticacionInterface;

public class Basededatos {
public static void main(String args[]) throws RemoteException{
		
		int opcion = 0;
		
		
		AlmacenBasededatos almacen = new AlmacenBasededatos();
		ServicioDatosImpl informacion= new ServicioDatosImpl();
		informacion.setAlmacen(almacen);
		ServicioDatosInterface stub= (ServicioDatosInterface)UnicastRemoteObject.exportObject(informacion, 2);
		Registry registry = LocateRegistry.createRegistry(1099);
		registry.rebind("informacion", stub);
		
		
		

		
		//TODO Registrar objeto remoto
		
		
		while(opcion != 4){
			
			opcion = mostrarMenu();
			switch(opcion){
				case 1: break;
				case 2: listaUsuariosRegistrados(almacen); break;
				case 3: listarTrinos(almacen); break;
				case 4: break;
			}
		}
	}

	private static void listarTrinos(AlmacenBasededatos almacen) {
	// TODO Auto-generated method stub
	
}

	private static void listaUsuariosRegistrados(AlmacenBasededatos almacen) {
		List<DatosUsuario> usuarios = almacen.obtenerUsuarios();
		if(usuarios != null){
			for(DatosUsuario usuario : usuarios){
				System.out.println("Usuario: "+usuario.obtenerNick() + "(" +usuario.obtenerNombre() +")");
			}
			
		}
		
	
}

	private static int mostrarMenu() {
		int out = -1;
		System.out.println("1.- Informacion de la Base de Datos");
		System.out.println("2.- Lista Usuarios Registrados");
		System.out.println("3.- Listar Trinos");
		System.out.println("4.- Salir");
		
		Scanner scanner = new Scanner(System. in); 
		String input = scanner. nextLine();
		
		if(input != null){
			try{
				out = Integer.parseInt(input);
			}catch(NumberFormatException ex){
				System.err.println("Opcion no reconocida!!");
			}
		}
		scanner.close();
		
		return out;
		
	}
}
