package basedatos;

import java.rmi.RemoteException;
import java.util.List;

import usuario.CallbackUsuarioInterface;
import Common.DatosUsuario;
import Common.Trino;

public class ServicioDatosImpl implements ServicioDatosInterface {

	private AlmacenBasededatos almacen;
	
	
	

	public AlmacenBasededatos obtenerAlmacen() {
		return almacen;
	}



	public void setAlmacen(AlmacenBasededatos almacen) {
		this.almacen = almacen;
	}



	@Override
	public List<String> listarUsuarios() throws RemoteException {
	
		return	almacen.obtenerNicks();
		
	}


	@Override
	public List<Trino> autenticarUsuario(String nick,
			CallbackUsuarioInterface callback) throws RemoteException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public DatosUsuario obtenerDatosUsuario(String nick) throws RemoteException {
		return almacen.obtenerUsuario(nick);
	}

	@Override
	public List<Trino> actualizarUsuarioLogueado(String nick,
			CallbackUsuarioInterface callback) throws RemoteException {
		DatosUsuario datosUsuario = almacen.obtenerUsuario(nick);
		if(datosUsuario != null) {
			datosUsuario.setCallback(callback);
			return almacen.obtenerTrinosPendientes(nick);
		}
		return null;
		
	}

	@Override
	public boolean actualizarUsuarioDesLogueado(String nick)
			throws RemoteException {
		
		DatosUsuario datosUsuario = almacen.obtenerUsuario(nick);
		if(datosUsuario != null) {
			datosUsuario.setCallback(null);
			return true;
		}		
		
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<DatosUsuario> obtenerSeguidores(String obtenerNickPropietario)
			throws RemoteException {
		return almacen.obtenerSeguidores(obtenerNickPropietario);
	}

	@Override
	public List<Trino> obtenerTrinosPendientes(String obtenerNick)
			throws RemoteException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void anadirTrinoPendiente(DatosUsuario seguidor, Trino trino)
			throws RemoteException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Trino> obtenerTrinosNoPublicados(String obtenerNick)
			throws RemoteException {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public boolean aniadirSeguidorUsuario(String nick, String nickObjetivo)
			throws RemoteException {
		return almacen.seguirUsuario(nick, nickObjetivo);
	}



	@Override
	public boolean borrarSeguidorUsuario(String nick, String nickObjetivo)
			throws RemoteException {
		return almacen.dejarSeguirUsuario(nick, nickObjetivo);
	}



	@Override
	public boolean addUsuario(String nombre, String nick, String password) 
	
			throws RemoteException {
		
		return almacen.addUsuario(nombre,nick,password);
		
	}

	

}
