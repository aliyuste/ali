package Common;

import java.io.Serializable;

import usuario.CallbackUsuarioInterface;

public class DatosUsuario implements Serializable{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String nick;
	
	private String nombre;
	
	private String password;
	
	private CallbackUsuarioInterface callback;
	
	
	public DatosUsuario(){
	}
	
	public DatosUsuario(String nick, String nombre, String password) {
		
		this.nick=nick;
		this.nombre=nombre;
		this.password=password;
	}
	
	public String obtenerNick() {
		return nick;
	}

	public void setNick(String nick) {
		this.nick = nick;
	}

	public String obtenerNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String obtenerPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public CallbackUsuarioInterface obtenerCallback() {
		return callback;
	}

	public void setCallback(CallbackUsuarioInterface callback) {
		this.callback = callback;
	}
	
	
	
	
}
