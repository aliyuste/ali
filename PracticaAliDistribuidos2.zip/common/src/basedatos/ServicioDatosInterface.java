package basedatos;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

import usuario.CallbackUsuarioInterface;
import Common.DatosUsuario;
import Common.Trino;

public interface ServicioDatosInterface extends Remote {
	

	boolean aniadirSeguidorUsuario(String nick, String nickObjetivo) throws RemoteException;
	
	boolean borrarSeguidorUsuario(String nick, String nickObjetivo) throws RemoteException;
	
	List<String> listarUsuarios() throws RemoteException;

	List<Trino> obtenerTrinosPendientes(String obtenerNick) throws RemoteException;

	List<Trino> autenticarUsuario(String nick,
			CallbackUsuarioInterface callback) throws RemoteException;

	DatosUsuario obtenerDatosUsuario(String nick) throws RemoteException;

	List<Trino> actualizarUsuarioLogueado(String nick,
			CallbackUsuarioInterface callback) throws RemoteException;

	boolean actualizarUsuarioDesLogueado(String nick) throws RemoteException;

	List<DatosUsuario> obtenerSeguidores(String obtenerNickPropietario) throws RemoteException;

	void anadirTrinoPendiente(DatosUsuario seguidor, Trino trino) throws RemoteException;

	List<Trino> obtenerTrinosNoPublicados(String obtenerNick) throws RemoteException;

	boolean addUsuario(String nombre, String nick, String password)throws RemoteException;
}
