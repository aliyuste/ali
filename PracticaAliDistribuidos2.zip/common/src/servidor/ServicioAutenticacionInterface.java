package servidor;

import java.rmi.Remote;
import java.rmi.RemoteException;

import usuario.CallbackUsuarioInterface;
import Common.DatosUsuario;

public interface ServicioAutenticacionInterface extends Remote {

	
	boolean registrar(String nombre, String nick, String password) throws RemoteException;
	
	DatosUsuario autenticar(String nick, String password,CallbackUsuarioInterface callback) throws RemoteException;

	boolean salir(String obtenerNick) throws RemoteException;
}

