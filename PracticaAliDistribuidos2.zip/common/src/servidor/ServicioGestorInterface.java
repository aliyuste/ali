package servidor;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

import Common.Trino;

public interface ServicioGestorInterface extends Remote {

	boolean seguirUsuario(String nick, String nickObjetivo) throws RemoteException;
	
	boolean dejarSeguirUsuario(String nick, String nickObjetivo) throws RemoteException;
	
	boolean publicarTrino(String nick, Trino trino) throws RemoteException;
	
	boolean borrarTrino(String nick, String identificadorTrino) throws RemoteException;

	List<String> listarUsuarios() throws RemoteException;

	List<Trino> obtenerTrinos(String obtenerNick) throws RemoteException;
	
}
