package usuario;

import java.rmi.Remote;
import java.rmi.RemoteException;

import Common.Trino;

public interface CallbackUsuarioInterface extends Remote {

	void enviarTrino(Trino trino) throws RemoteException;
}
