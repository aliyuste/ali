package servidor;

import java.rmi.RemoteException;
import java.util.List;

import basedatos.ServicioDatosInterface;
import usuario.CallbackUsuarioInterface;
import Common.DatosUsuario;
import Common.Trino;

public class ServicioAutenticacionImpl implements ServicioAutenticacionInterface {

	private ServicioDatosInterface datos;

	public ServicioAutenticacionImpl(ServicioDatosInterface informacion) {
		// TODO Auto-generated constructor stub

		datos = informacion;
	}

	@Override
	public boolean registrar(String nombre, String nick, String password) throws RemoteException {

		return datos.addUsuario(nombre, nick, password);

	}

	@Override
	public DatosUsuario autenticar(String nick, String password, CallbackUsuarioInterface callback) {
		// Obtenemos los datos de base de datos
		try {
			DatosUsuario usuario = datos.obtenerDatosUsuario(nick);
			// Validamos las credenciales del usuario
			if (usuario != null) {

				if (usuario.obtenerPassword() != null && usuario.obtenerPassword().equals(password)) {
					// Guardamos los datos del callback en base de datos y recuperamos los trinos
					// pendientes para ese usuario

					List<Trino> pendientesEnviar = datos.actualizarUsuarioLogueado(nick, callback);
					if (pendientesEnviar != null) {
						// Por cada uno de ellos, lo vamos enviando al usuario que acaba de entrar en el
						// sistema
						for (Trino pendiente : pendientesEnviar) {
							callback.enviarTrino(pendiente);
						}
					}
					return usuario;
				}

			}
		} catch (RemoteException e) {
			handleRemoteException(e);
		}
		return null;

	}

	@Override
	public boolean salir(String nick) {
		// Obtenemos los datos de base de datos
		try {
			DatosUsuario usuario = datos.obtenerDatosUsuario(nick);
			if (usuario != null) {
				return datos.actualizarUsuarioDesLogueado(nick);
			}
		} catch (RemoteException e) {
			handleRemoteException(e);
		}
		return false;
	}

	private void handleRemoteException(RemoteException ex) {
		System.err.println("Error! No se ha podido realizar la comunicacion remota: " + ex.getMessage());
	}

}
