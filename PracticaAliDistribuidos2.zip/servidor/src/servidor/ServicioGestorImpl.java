package servidor;

import java.rmi.RemoteException;
import java.util.List;

import basedatos.ServicioDatosInterface;
import usuario.CallbackUsuarioInterface;
import Common.DatosUsuario;
import Common.Trino;

public class ServicioGestorImpl implements ServicioGestorInterface {

	private ServicioDatosInterface datos;
	
	public ServicioGestorImpl(ServicioDatosInterface informacion) {
		// TODO Auto-generated constructor stub
		datos=informacion;
	}

	@Override
	public boolean seguirUsuario(String nick, String nickObjetivo) {
		try {
			return datos.aniadirSeguidorUsuario(nick, nickObjetivo);
		} catch (RemoteException e) {
			handleRemoteException(e);
		}
		return false;
	}

	@Override
	public boolean dejarSeguirUsuario(String nick, String nickObjetivo) {
		try {
			return datos.borrarSeguidorUsuario(nick, nickObjetivo);
		} catch (RemoteException e) {
			handleRemoteException(e);
		}
		return false;
	}

	@Override
	public boolean publicarTrino(String nick, Trino trino) {
		
		List<DatosUsuario> seguidores;
		try {
			seguidores = datos.obtenerSeguidores(trino.ObtenerNickPropietario());
			
			if(seguidores != null){
				System.out.println("1");
				for(DatosUsuario seguidor : seguidores){
					
					//Si el callback esta asignado con valor, indica que el usuario está actualmente logueado y se le envia ya el trino
					CallbackUsuarioInterface callback = seguidor.obtenerCallback();
					if(callback != null){
						System.out.println("2");
						callback.enviarTrino(trino);
					}else{
						System.out.println("3");
						//Si no se le añade para que se le informe cuando se vuelva a loguear
						datos.anadirTrinoPendiente(seguidor,trino);
					} 
				}
			}
			return true;
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean borrarTrino(String nick, String identificadorTrino) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<String> listarUsuarios() throws RemoteException {
		return datos.listarUsuarios();
	}

	@Override
	public List<Trino> obtenerTrinos(String obtenerNick) {
		try {
			return datos.obtenerTrinosNoPublicados(obtenerNick);
		} catch (RemoteException e) {
			handleRemoteException(e);
		}
		return null;
	}
	
	private void handleRemoteException(RemoteException ex){
		System.err.println("Error! No se ha podido realizar la comunicacion remota: "+ex.getMessage());
	}

}
