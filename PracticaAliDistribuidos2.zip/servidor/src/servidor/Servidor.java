package servidor;

import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.Scanner;

import basedatos.ServicioDatosInterface;

public class Servidor {

	
	public static void main(String args[]) throws RemoteException, NotBoundException{
		
		
		
		int opcion = 0;
		
		//TODO Registrar objeto remoto
		//TODO Obtener referencia al objeto base de datos;
		Registry registry = LocateRegistry.getRegistry(1099);
		ServicioDatosInterface informacion= (ServicioDatosInterface)registry.lookup("informacion");
		
		ServicioAutenticacionInterface autenticador= new ServicioAutenticacionImpl(informacion); 
		ServicioAutenticacionInterface stub= (ServicioAutenticacionInterface)UnicastRemoteObject.exportObject(autenticador, 0);
	
		registry.rebind("autenticador", stub);
		
		
		ServicioGestorInterface gestor= new ServicioGestorImpl(informacion);
		ServicioGestorInterface stub1=(ServicioGestorInterface)UnicastRemoteObject.exportObject(gestor,1);
		registry.rebind("gestor", stub1);
	
	
		
		
			
		while(opcion != 3){
			
			opcion = mostrarMenu();
			switch(opcion){
				case 1: break;
				case 2: break;
				case 3: break;
			}
		}
	}

	private static int mostrarMenu() {
		int out = -1;
		System.out.println("1.- Informacion del servidor");
		System.out.println("2.- Lista Usuarios Logeados");
		System.out.println("3.- Salir");
		
		Scanner scanner = new Scanner(System. in); 
		String input = scanner. nextLine();
		
		if(input != null){
			try{
				out = Integer.parseInt(input);
			}catch(NumberFormatException ex){
				System.err.println("Opcion no reconocida!!");
			}
		}
		scanner.close();
		
		return out;
		
	}
}
