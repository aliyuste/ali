package usuario;

import java.io.Serializable;

import Common.Trino;

public class CallbackUsuarioImpl implements CallbackUsuarioInterface {

	@Override
	public void enviarTrino(Trino trino) {
		System.out.println(trino.ObtenerNickPropietario()+"# "+trino.ObtenerTrino());

	}

}
