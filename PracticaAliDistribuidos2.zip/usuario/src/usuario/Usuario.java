package usuario;

import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.Scanner;

import servidor.ServicioAutenticacionInterface;
import servidor.ServicioGestorInterface;

public class Usuario {
	
	public static Scanner scanner = new Scanner(System.in); 

public static void main(String args[]) throws RemoteException, NotBoundException{
		
		int opcion = 0;
		
		
		
		Registry registry= LocateRegistry.getRegistry();
		ServicioAutenticacionInterface autenticar= (ServicioAutenticacionInterface)registry.lookup("autenticador");
		
		ServicioGestorInterface gestor= (ServicioGestorInterface)registry.lookup("gestor");
		
		CallbackUsuarioInterface callback = new CallbackUsuarioImpl();
		CallbackUsuarioInterface stub= (CallbackUsuarioInterface)UnicastRemoteObject.exportObject(callback, 0);
		registry.rebind("callback", stub);
		
		boolean usuarioLogueado = false; //Mientras la variable esta false seguimos mostrando el menu inicial y no puede ver el de acciones
		boolean usuarioDeslogueado= false; // Mientras esta variable este a false se muestra el menu inicial
		
		//TODO ObtenerReferencias a los objetos remotos!!!!
		UsuarioAcciones acciones = new UsuarioAcciones(autenticar,gestor,callback);
		
			
		while(!usuarioLogueado){
			
			opcion = mostrarMenuRegistro();
			switch(opcion){
				case 1: acciones.registrar(); break;
				case 2: usuarioLogueado = acciones.autenticar(); break;
				case 3: System.exit(1); break;

			}
		}
		
		while(opcion != 7){
			
			opcion = mostrarMenu();
			switch(opcion){
				case 1: acciones.informacionDelUsuario(); break;
				case 2: acciones.enviarTrino(); break;
				case 3: acciones.listarUsuarios(); break;
				case 4: acciones.seguir(); break;
				case 5: acciones.dejarDeSeguir();break;
				case 6: acciones.BorrarTrino(); break;
				case 7: usuarioDeslogueado=acciones.salir();break;

			}
		}
	}
	
   
	private static int mostrarMenuRegistro() {
		int out = -1;
		System.out.println("1.- Registrar un nuevo usuario");
		System.out.println("2.- Hacer login");
		System.out.println("3.- Salir");
		

		if(scanner.hasNextLine()) {
		String input = scanner. nextLine();
		
		if(input != null){
			try{
				out = Integer.parseInt(input);
			}catch(NumberFormatException ex){
				System.err.println("Opcion no reconocida!!");
			}
		}
		}
		
		return out;
}

	private static int mostrarMenu() {
		int out = -1;
		System.out.println("1.- Informaci�n del usuario");
		System.out.println("2.- Enviar trino");
		System.out.println("3.- Lista Usuarios del Sistema");
		System.out.println("4.- Seguir a");
		System.out.println("5.- Dejar de seguir a");
		System.out.println("6.- Borrar trino a los usuarios que no lo han recibido");
		System.out.println("7.- Salir (logout)");
		
		

		if(scanner.hasNextLine()) {
		String input = scanner. nextLine();
		
		if(input != null){
			try{
				out = Integer.parseInt(input);
			}catch(NumberFormatException ex){
				System.err.println("Opcion no reconocida!!");
			}
		}
		}

		return out;
		
	}
}
