package usuario;

import java.rmi.RemoteException;
import java.util.List;
import java.util.Scanner;

import Common.DatosUsuario;
import Common.Trino;
import servidor.ServicioAutenticacionInterface;
import servidor.ServicioGestorInterface;

public class UsuarioAcciones {

	private DatosUsuario usuario;
	private ServicioGestorInterface gestor;
	private ServicioAutenticacionInterface autenticador;
	private CallbackUsuarioInterface callback;
	
	public UsuarioAcciones(ServicioAutenticacionInterface autenticar, ServicioGestorInterface gestor2,CallbackUsuarioInterface callback) {
		this.gestor = gestor2;
		this.autenticador = autenticar;
		this.callback = callback;
	}

	public  void dejarDeSeguir() {
		System.out.println("Accion: Dejar de seguir");
		String nick = recibirParametro("Nick:");
		try{
			boolean resultado = gestor.dejarSeguirUsuario(usuario.obtenerNick(), nick);
			if(resultado){
				System.out.println("Se ha dejado de seguir correctamente a: "+nick);
			}else{
				System.err.println("Error!! No se ha dejado de seguir a: "+nick);
			}
		} catch (RemoteException e) {
			handleRemoteException(e);
		}
	}

	public boolean autenticar() {
		String nick = recibirParametro("Nick:");
		String password = recibirParametro("Password:");
		
		
		try{
			DatosUsuario usuario = autenticador.autenticar(nick, password,callback);
			if(usuario != null){
				this.usuario = usuario;
				System.out.println("Usuario logueado correctamente en el sistema!");
			}else{
				System.err.println("ERROR! No se ha podido loguear al usuario");
			}
			return usuario != null;
		} catch (RemoteException e) {
			handleRemoteException(e);
		}
		return false;
	}

	public void seguir() {
		System.out.println("Accion: Seguir");
		String nick = recibirParametro("Nick:");
		try{
			boolean resultado = gestor.seguirUsuario(usuario.obtenerNick(), nick);
			if(resultado){
				System.out.println("Se ha seguido correctamente al usuario: "+nick);
			}else{
				System.err.println("ERROR! No se ha podido seguir al usuario: "+nick);
			}
		} catch (RemoteException e) {
			handleRemoteException(e);
		}
	}

	public void informacionDelUsuario() {
		System.out.println("Accion: Informacion del usuario");
		System.out.println("Nick: "+usuario.obtenerNick());
		System.out.println("Nombre: "+usuario.obtenerNombre());
		
	}

	public void BorrarTrino() {
		System.out.println("Accion: Borrar Trino");
		try{
			List<Trino> trinos = gestor.obtenerTrinos(usuario.obtenerNick());
			if(trinos != null){
				for(Trino trino : trinos){
					System.out.println("Trino ID:"+trino.toString());
					recibirParametro("Indique el trino a borrar:");
				}
			}
		} catch (RemoteException e) {
			handleRemoteException(e);
		}
	}

	public void enviarTrino() {
		System.out.println("Accion: Enviar Trino");
		String mensaje = recibirParametro("Mensaje:");
		Trino trino = new Trino(mensaje,usuario.obtenerNick());
		try{
			boolean resultado = gestor.publicarTrino(usuario.obtenerNick(), trino);
			if(resultado){
				System.out.println("Trino publicado correctamente!");
			}else{
				System.out.println("Error! No se ha podido publicar el Trino");
	
			}
		} catch (RemoteException e) {
			handleRemoteException(e);
		}
	}

	public void registrar() {
		System.out.println("Accion: Registrar");
		String nick = recibirParametro("Nick:");
		String nombre = recibirParametro("Nombre:");
		String password = recibirParametro("Password:");
		try{
			boolean resultado = autenticador.registrar(nombre, nick, password);
			if(resultado){
				System.out.println("Usuario registrado correctamente!");
			}else{
				System.err.println("Error! No se ha podido registrar al usuario");
			}
		} catch (RemoteException e) {
			handleRemoteException(e);
		}
		
	}

	public void listarUsuarios() {
		System.out.println("Accion: Listar Usuarios");
		List<String> usuarios;
		try {
			usuarios = gestor.listarUsuarios();
			if(usuarios != null){
			for(String usuario : usuarios){
				System.out.println(usuario);
			}
			}
		} catch (RemoteException e) {
			handleRemoteException(e);
		}
	}
	
	private String recibirParametro(String texto){
		String input = "";
		System.out.println(texto);
		Scanner scanner = Usuario.scanner;
		if(scanner.hasNextLine()) {
			input = scanner. nextLine();
		}

		
		return input;
	}
	
	private void handleRemoteException(RemoteException ex){
		System.err.println("Error! No se ha podido realizar la comunicacion remota: "+ex.getMessage());
	}

	public boolean salir() {
		try{
			boolean resultado = autenticador.salir(usuario.obtenerNick());
			if(resultado){
				System.out.println("Usuario desvincular correctamente!");
				return resultado;
				
			}else{
				System.err.println("Error! No se ha podido desvincular al usuario");
			}
		} catch (RemoteException e) {
			handleRemoteException(e);
		}
		return false;
	}

}
